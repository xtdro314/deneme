#### PLEASE READ THE POSTING GUIDELINES AND ANSWER THE QUESTION BEFORE POSTING, OTHERWISE ISSUE WILL BE CLOSED AND MARKED AS INVALID

* I hereby declare the following issue is a **[tool specific question/bug report]** and it is **NOT** a help request about creating a phishlet.
* I am fully aware that this is not a customer support portal, I can't demand answers and I'm aware I am using a free tool.
* I am not going to use Evilginx to hax my girlfriend's account or use it for any other illegal purpose.
* I am not trying to set up a domain on FreeNOM (also read the sentence above again).
* I am not a robot.
*(Sorry, if you are an adult and a professional and you had to read this.)*

Please type in "**I CONFIRM**" below if you confirm the sentences above or otherwise make some funny remark:

*<type_in_here>*

Thanks!
--

